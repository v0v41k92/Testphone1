require('./bootstrap');
require('../../node_modules/jqueryui/jquery-ui.min.js');

function createXML(){

  $.ajax({
      type:'POST',
      async: false,
      url: "/",
      dataType: 'html',
      success:function(data){
        $('#xml-place').html(data);
        window.open('/xml/xmlContact.xml', '_blank');
      }
  });
}
