<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
})->name('home');*/

Route::get('/add_contact', function () {
    return view('add_contact');
})->name('contact');
Route::get('/search', function () {
    return view('search');
})->name('search');


Route::get('/add_contact','App\Http\Controllers\GroupController@allData1')->name('contact');

Route::get('/contact/update={id}', 'App\Http\Controllers\ContactController@contactUpdate')->name('contact-update');
Route::get('/contact/delete={id}', 'App\Http\Controllers\ContactController@contactDelete')->name('contact-delete');
Route::post('/contact/update={id}', 'App\Http\Controllers\ContactController@contactUpdateSucces')->name('contact-update-succes');

Route::get('/contact/edit={id}', 'App\Http\Controllers\ContactController@contactEdit')->name('contact-edit');
Route::get('/', 'App\Http\Controllers\ContactController@allData')->name('home');
Route::post('/', 'App\Http\Controllers\AjaxController@createXMLAction')->name('home');
Route::post('/add_contact/submit', 'App\Http\Controllers\ContactController@submit')->name('contact-form');

Route::get('/search', 'App\Http\Controllers\ContactController@Search')->name('search');
Route::get('/group', 'App\Http\Controllers\ContactController@SearchGroup')->name('group');
Route::post('/group', 'App\Http\Controllers\ContactController@allData')->name('group');
