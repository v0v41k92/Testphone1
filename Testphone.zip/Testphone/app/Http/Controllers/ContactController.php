<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Http\Requests\ContactRequest;
use App\Models\Contact;
use App\Models\Group;

class ContactController extends Controller{

  public function submit(ContactRequest $req){

    $contact= new Contact();
    $contact->name = $req->input('name');
    $contact->number = $req->input('number');
    $contact->email = $req->input('email');
    $contact->group = implode(",",$req->group);
    $contact->save();

    return redirect()->route('home')->with('succes','Контакт добавлен');

    //dd($req->group);
  }

  public function Search(Request $req){
    $s = $req->s;
    $user = Contact::where('name','LIKE',"%{$s}%")
                  ->orWhere('number','LIKE',"%{$s}%")
                  ->orWhere('email','LIKE',"%{$s}%")
                  -> orderBy('name')->paginate(10);
    return view ('/Search',compact('user'));
  }

  public function SearchGroup(Request $req){
    $q = $req->q;
    $group = new Group;
    $user = Contact::where('group','LIKE',"%{$q}%")
                  -> orderBy('name')->paginate(10);
    return view ('/group',compact('user'), ['group'=>$group->all()]);
  }

  public function allData(){
    $contact = new Contact;
    $group = new Group;
    return view('welcome',['data'=>$contact->all()], ['group'=>$group->all()]);
  }

  public function contactEdit($id){
    $contact = new Contact;
    $finds = chekbox::wheName($name)->get();
    foreach($finds as $find){array_puch($group, $find->group);}
    return view('edit-contact',compact('contact','group'));
  }

  public function contactUpdate($id){
    $contact = new Contact;
    $group = new Group;
    return view('update-contact',['data'=>$contact->find($id)], ['group'=>$group->all()]);
  }


  public function contactUpdateSucces($id, ContactRequest $req){

    $contact= Contact::find($id);
    $contact->name = $req->input('name');
    $contact->number = $req->input('number');
    $contact->email = $req->input('email');
    $contact->group = implode(",", $req->group);
    $contact->save();

    return redirect()->route('home')->with('succes','Контакт обновлен');
  }

public function contactDelete($id){
  Contact::find($id)->delete();
    return redirect()->route('home')->with('succes','Контакт удален');
}

 function createXMLAction(){
    $export = new Contact;
dd($export->all());
  /*  $xml = new DOMDocument('1.0', 'utf-8');
    $xmlContact = $xml->appendChild($xml->createElement('contacts'));

    foreach ($export as $contact) {
      $xmlContact = $xmlContacts->appendChild($xml->createElement('contact'));
      foreach ($contact as $key => $val) {
        $xmlName = $xmlContact->appendChild($xml->createElement($key));
        $xmlName = appendChild($xml->createTextNode($val));
      }
    }

    $xml->save($_SERVER["DOCUMENT_ROOT"].'/xml/contacts.xml');
    echo 'ok';*/
  }


}
