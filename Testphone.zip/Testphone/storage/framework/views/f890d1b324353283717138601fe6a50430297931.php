<?php $__env->startSection('title-block'); ?>Редактировать контакт: <?php echo e($data->name); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Редактировать контакт: <?php echo e($data->name); ?></h1>

  <div class="alert alert-info">
    <p><b>Имя:  </b><?php echo e($data->name); ?></p>
    <p><b>Номер  :</b><?php echo e($data->number); ?></p>
    <p><b>E-mail:  </b><?php echo e($data->email); ?></p>
    <a href="<?php echo e(route('contact-update', $data->id)); ?>"><button class="btn btn-primary" >Редактировать</button>
  </div></a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Testphone\resources\views/edit-contact.blade.php ENDPATH**/ ?>