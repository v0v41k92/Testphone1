<html>
   <head>
      <title>Ajax Example</title>

      <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
      </script>

      <script>
         function getMessage() {
            $.ajax({
               type:'POST',
               url:'/getmsg',
               data:'_token = <?php echo csrf_token() ?>',
               success:function(data) {
                  $("#msg").html(data.msg);
               }
            });
         }

         function createXML(){

           $.ajax({
               type:'PUT',
               async: false,
               url: "/getmsg",
               dataType: '_token = <?php echo csrf_token() ?>',
               success:function(data){
                 $('#xml-place').html(data);
                 window.open('http://127.0.0.1:8000/xml/xmlContact.xml', '_blank');
               }
           });
         }

      </script>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   </head>

   <body>


     <input type="button" onclick="createXML();" value="Import to XML">
     <div id="xl-place"></div>

      <div id = 'msg'>This message will be replaced using Ajax.
         Click the button to replace the message.</div>

        <input type="button" value='Replace Message' onClick='getMessage()'>

   </body>
<script type="text/javascript">
$.ajaxSetup({
headers: {
  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
});
</script>
</html>
<?php /**PATH C:\MAMP\htdocs\Testphone\resources\views/message.blade.php ENDPATH**/ ?>