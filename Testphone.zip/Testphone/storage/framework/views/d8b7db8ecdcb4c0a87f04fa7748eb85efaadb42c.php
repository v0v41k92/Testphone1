<?php if($errors->any()): ?>
<div class="alert alert-danger">
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>

</div>
<?php endif; ?>
<?php if(session('succes')): ?>
<div class="alert alert-succes">
  <?php echo e(session('succes')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\MAMP\htdocs\Testphone\resources\views/inc/messages.blade.php ENDPATH**/ ?>