<footer class="footer mt-auto py-3 bg-light">
  <div class="container">
    <span class="text-muted">2021</span>
  </div>
</footer>
<?php /**PATH C:\MAMP\htdocs\Testphone\resources\views/inc/footer.blade.php ENDPATH**/ ?>