<?php $__env->startSection('title-block'); ?>Обновить контакт<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>Обновить контакт</h1>



  <form action="<?php echo e(route('contact-update-succes', $data->id)); ?>" method="post">
  <?php echo csrf_field(); ?>

    <div class="form-group">
      <label for="name">Введите имя</label>
      <input type="text" name="name" value="<?php echo e($data->name); ?>" placeholder="Введите имя" id="name" class="form-control"></label>
    </div>
    <div class="form-group">
      <label for="number">Введите номер</label>
      <input type="text" name="number" value="<?php echo e($data->number); ?>" placeholder="Введите номер" id="number" class="form-control"></label>
    </div>
    <div class="form-group">
      <label for="email">email</label>
      <input type="text" name="email" value="<?php echo e($data->email); ?>" placeholder="Введите email" id="email" class="form-control"></label>
    </div>
    <div class="form-group">
      <label for="group">Выберите группу:</br></label>
    </div>
        <fieldset id="check">

          <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="checkbox">
              <input type="checkbox" name="group[]"  value="<?php echo e($el->name); ?>"><label><?php echo e($el->name); ?></label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </fieldset>

    <button type="submit" clas="btn btn-succes">Обновить</button>

  </form>
  <a href="<?php echo e(route('home')); ?>"><button type="submit" clas="btn btn-succes">Назад</button></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Testphone\resources\views/update-contact.blade.php ENDPATH**/ ?>