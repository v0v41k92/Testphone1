

<?php $__env->startSection('title-block'); ?>Результат поиска<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Результат поиска</h1>
<div class="row col-md-12">
  <form action="<?php echo e(route('search')); ?>" method="get">
  <div class="form-group col-md-10">
    <label for="name">Поиск:</label>
    <input type="text" name="s" id="s" placeholder="Что нужно искать?" class="form-control"></label>
  </div>

  <div class="form-group col-md-2">
    <button type="submit" clas="btn btn-primary btn-block">Поиск</button>
  </div>
</form>
</div>

<?php if(count($user)): ?>

<div class="table-responsive">
<table class="table table-hover table-striped">
 <thead>
  <tr>
   <th scope="col">Имя</th>
   <th scope="col">Номер</th>
   <th scope="col">Електронная почта</th>
  </tr>
 </thead>
 <tbody>
   <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($el->name); ?></td>
    <td><?php echo e($el->number); ?></td>
    <td><?php echo e($el->email); ?></td>
   </tr>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
</table>
</div>
<?php else: ?> <div class="alert alert-info">Записей нет</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Testphone\resources\views//Search.blade.php ENDPATH**/ ?>