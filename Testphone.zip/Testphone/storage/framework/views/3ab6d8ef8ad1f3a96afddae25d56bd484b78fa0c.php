

<?php $__env->startSection('title-block'); ?>Добавить контакт<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>Добавить контакт</h1>



  <form action="<?php echo e(route('contact-form')); ?>" method="post">
  <?php echo csrf_field(); ?>

    <div class="form-group">
      <label for="name">Введите имя</label>
      <input type="text" name="name" placeholder="Введите имя" id="name" class="form-control"></label>
    </div>
    <div class="form-group">
      <label for="number">Введите номер</label>
      <input type="text" name="number" placeholder="Введите номер" id="number" class="form-control"></label>
    </div>
    <div class="form-group">
      <label for="email">email</label>
      <input type="text" name="email" placeholder="Введите email" id="email" class="form-control"></label>
    </div>
    <div class="form-group">
      <label for="group">Выберите группу:</br></label>
    </div>
        <fieldset id="check">

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="checkbox">
              <input type="checkbox" name="group[]"  value="<?php echo e($el->name); ?>"><label><?php echo e($el->name); ?></label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </fieldset>

    <button type="submit" clas="btn btn-succes">Сохранить</button>

  </form>
<a href="<?php echo e(route('home')); ?>"><button clas="btn btn-danger">Отмена</button></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Testphone\resources\views//add_contact.blade.php ENDPATH**/ ?>