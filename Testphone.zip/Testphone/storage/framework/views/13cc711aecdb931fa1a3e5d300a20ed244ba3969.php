<?php $__env->startSection('title-block'); ?>Телефонная книга<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Телефонная книга</h1>
<div class="row">
<div class="col-md-8"><input type="button" onclick="createXML();" value="Import to XML">
<div id="xml-place"></div></div>
<div class="col-md-4">
<form action="<?php echo e(route('group')); ?>" method="get">
<?php echo csrf_field(); ?>

<div class="form-group">
  <label for="g">Выберите группу:</br></label>

  <select class="" name="q">

    <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($el->name); ?>"><?php echo e($el->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </select>
  <button type="submit" clas="btn btn-primary btn-block">Просмотр</button>
</div>
</form>
</div>

<div class="table-responsive">
<table class="table table-hover table-striped">
 <thead>
  <tr>
     <th scope="col"><input type="checkbox" name="allContact[]"  value="all"></th>
     <th scope="col">Имя</th>
     <th scope="col">Номер</th>
     <th scope="col">Електронная почта</th>
  </tr>
 </thead>
 <tbody>
   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><input type="checkbox" name="Contact[]"  value="<?php echo e($el->name); ?>"></td>
    <td><?php echo e($el->name); ?></td>
    <td><?php echo e($el->number); ?></td>
    <td><?php echo e($el->email); ?></td>
    <td><a href="<?php echo e(route('contact-update', $el->id)); ?>"><button class="btn btn-warning" >Редактировать</button></td>
    <td><a href="<?php echo e(route('contact-delete', $el->id)); ?>"><button type="submit" clas="btn btn-danger">Удалить</button></a></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
</table>
</div>
</div>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
   function createXML(){

     $.ajax({
         type:'POST',
         async: false,
         url: "/",
         dataType: '_token = <?php echo csrf_token() ?>',
         success:function(data){
           $('#xml-place').html(data);
           window.open('http://127.0.0.1:8000/xml/xmlContact.xml', '_blank');
         }
     });
   }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Testphone\resources\views/welcome.blade.php ENDPATH**/ ?>