

<?php $__env->startSection('title-block'); ?>Добавить контакт<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>Добавить контакт</h1>



  <form action="<?php echo e(route('search-form')); ?>" method="post">
  <?php echo csrf_field(); ?>

    <div class="form-group">
      <label for="name">Поиск:</label>
      <input type="text" name="search" placeholder="Что нужно искать?" id="name" class="form-control"></label>
    </div>


    <button type="submit" clas="btn btn-succes">Поиск</button>

  </form>
<a href="<?php echo e(route('home')); ?>"><button clas="btn btn-danger">Отмена</button></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Testphone\resources\views/search.blade.php ENDPATH**/ ?>